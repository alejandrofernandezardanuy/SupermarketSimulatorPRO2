var searchData=
[
  ['minutos_129',['minutos',['../class_hora.html#a06f705a1aa98a4264f360a85746ed616',1,'Hora']]]
];
