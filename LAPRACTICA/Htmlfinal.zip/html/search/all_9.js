var searchData=
[
  ['quiere_5fcomprar_51',['quiere_comprar',['../class_cliente.html#a1aa38e379e4e8db6882f3cd1bbe8d3ca',1,'Cliente::quiere_comprar()'],['../class_conj_clientes.html#a5da024a4de6c718ec3625fd6c70ef563',1,'ConjClientes::quiere_comprar()']]],
  ['quiere_5fprod_52',['quiere_prod',['../class_cliente.html#a4ab129f924e88506563391e5cc647b5b',1,'Cliente']]]
];
