var searchData=
[
  ['salas_54',['salas',['../class_tienda.html#a03a569f13a21df5e5424f58773b1ace1',1,'Tienda']]],
  ['salas_5fa_5fvisitar_55',['salas_a_visitar',['../class_cliente.html#a691f493e535cb2beaa33d0047538cb73',1,'Cliente::salas_a_visitar()'],['../class_conj_clientes.html#ae4bd067ebb9ff63df829c49b576945c1',1,'ConjClientes::salas_a_visitar()']]],
  ['salas_5frecorrido_56',['salas_recorrido',['../class_cliente.html#adde72e47cad87b8f905d4ae1e79d36ad',1,'Cliente']]],
  ['segundos_57',['segundos',['../class_hora.html#aec2cfd1b24dcf567500c0871ebbdc6a9',1,'Hora']]],
  ['sumar_5fsegundos_58',['sumar_segundos',['../class_hora.html#af9c04e9e3da6919e7b79b30dff708c07',1,'Hora']]]
];
