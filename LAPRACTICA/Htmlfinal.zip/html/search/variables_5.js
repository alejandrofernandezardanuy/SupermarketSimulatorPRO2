var searchData=
[
  ['salas_131',['salas',['../class_tienda.html#a03a569f13a21df5e5424f58773b1ace1',1,'Tienda']]],
  ['salas_5frecorrido_132',['salas_recorrido',['../class_cliente.html#adde72e47cad87b8f905d4ae1e79d36ad',1,'Cliente']]],
  ['segundos_133',['segundos',['../class_hora.html#aec2cfd1b24dcf567500c0871ebbdc6a9',1,'Hora']]]
];
