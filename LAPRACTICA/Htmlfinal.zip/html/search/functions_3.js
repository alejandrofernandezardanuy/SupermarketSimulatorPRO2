var searchData=
[
  ['hora_99',['Hora',['../class_hora.html#a90c18369977bbf1bf3a7370d8ea9e9ae',1,'Hora::Hora()'],['../class_hora.html#aece92fc3f5c12e4bccffc4b461a19630',1,'Hora::Hora(int h, int m, int s)']]],
  ['hora_5fsalida_5fultimo_5fcola_100',['hora_salida_ultimo_cola',['../class_caja.html#a6b906523364084e85b8f44bb091ab6d8',1,'Caja']]]
];
