var searchData=
[
  ['este_20es_20mi_20proyecto_20sobre_20la_20reorganizacion_20de_20megathlon_2c_20en_20el_20cual_20podemos_20gestionar_20las_20salas_20por_20las_20que_20pasan_20los_20clientes_20para_20realizar_20su_20compra_20y_20asi_20hacerlos_20pasar_20por_20otras_20salas_20i_20maximizar_20los_20beneficios_20de_20la_20tienda_20en_20cuestion_2e_135',['Este es mi proyecto sobre la reorganizacion de megathlon, en el cual podemos gestionar las salas por las que pasan los clientes para realizar su compra y asi hacerlos pasar por otras salas i maximizar los beneficios de la tienda en cuestion.',['../index.html',1,'']]]
];
