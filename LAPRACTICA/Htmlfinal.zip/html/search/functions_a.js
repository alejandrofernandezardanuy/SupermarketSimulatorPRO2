var searchData=
[
  ['restar_5fhoras_117',['restar_horas',['../class_hora.html#abd67e5de44c5c54525f21263c1d9e5e3',1,'Hora']]]
];
