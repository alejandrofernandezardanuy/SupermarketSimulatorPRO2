var searchData=
[
  ['igual_33',['igual',['../class_hora.html#aeff9e596b251807f2c316c4cf9cc98e0',1,'Hora']]],
  ['inicializar_34',['inicializar',['../class_conj_cajas.html#a79aec08594f4892b0edd8831d2fa471d',1,'ConjCajas']]],
  ['instrucciones_35',['instrucciones',['../class_tienda.html#af834ad8f3da220790f5eb5260e073d34',1,'Tienda']]]
];
