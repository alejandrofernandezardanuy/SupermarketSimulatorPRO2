var searchData=
[
  ['anadir_5fcliente_0',['anadir_cliente',['../class_caja.html#a13b669089f1dd28b6e126b2a3977f81f',1,'Caja']]],
  ['anadir_5fsala_1',['anadir_sala',['../class_cliente.html#aafdadc27a06795a894c235c0fb5175d7',1,'Cliente']]]
];
