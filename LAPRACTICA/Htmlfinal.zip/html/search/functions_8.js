var searchData=
[
  ['pasar_5fa_5fhms_113',['pasar_a_hms',['../class_hora.html#aa2018a476c0eb875599aa8029d278408',1,'Hora']]],
  ['pasar_5fa_5fseg_114',['pasar_a_seg',['../class_hora.html#a2d48ad1ab9af95a15ebe9cea8d81ce39',1,'Hora']]]
];
