var searchData=
[
  ['productos_5fcompra_5fno_5fquiere_130',['productos_compra_no_quiere',['../class_cliente.html#a0087ce6162f889e952f2992196a65756',1,'Cliente']]]
];
