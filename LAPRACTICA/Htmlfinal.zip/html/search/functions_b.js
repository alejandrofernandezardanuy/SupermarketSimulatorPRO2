var searchData=
[
  ['salas_5fa_5fvisitar_118',['salas_a_visitar',['../class_cliente.html#a691f493e535cb2beaa33d0047538cb73',1,'Cliente::salas_a_visitar()'],['../class_conj_clientes.html#ae4bd067ebb9ff63df829c49b576945c1',1,'ConjClientes::salas_a_visitar()']]],
  ['sumar_5fsegundos_119',['sumar_segundos',['../class_hora.html#af9c04e9e3da6919e7b79b30dff708c07',1,'Hora']]]
];
