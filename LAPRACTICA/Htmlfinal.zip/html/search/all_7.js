var searchData=
[
  ['nuevo_5fcliente_45',['nuevo_cliente',['../class_conj_clientes.html#a37a6e5da7329defa325229e3b2401322',1,'ConjClientes']]],
  ['num_5fproductos_46',['num_productos',['../class_cliente.html#ac69a34e4b69a25cf1cee691a2421ad07',1,'Cliente']]]
];
